namespace RoleplayGame.Items
{
    /// <summary>
    /// Interfaz para crear elementos.
    /// </summary>
    public interface IItem
    {
    }
}